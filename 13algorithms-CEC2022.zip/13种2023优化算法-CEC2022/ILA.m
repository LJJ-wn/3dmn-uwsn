function [Bests_Results,n_it_phase1,n_it_phase2,n_it_phase3,costs1,costs2,costs3] = ILA (nNL,nIt,Vmin,Vmax,nV,CostFunction)

%% Initialization
nModel = 2;               % Small, Moderate, Large, etc. (Number of Models for the initial phase)
mIt_Phase1 = 0.33;        % Maximum percent of the number of iterations for phase 1 (Default: 0.25)
mIt_Phase2 = 0.33;        % Maximum percent of the number of iterations for phase 2 (Default: 0.5)
Bmin = 0.4;               % Minimum value for Boundary (Default = 0.4)
Bmax = 0.6;               % Maximum value for Boundary (Default = 0.6)
nRep = 10;                % For clustering, specify nRep replicates to help find better clusters (Default: 10)
nIt_classification = 100; % Number of iterations to converge the classification during nRep replications (Default: 100)
Empty.NL = [];                                % Current NL
Empty.NLprevious = [];                        % Previous NL
Empty.Cost = inf;
Empty1.NL = [];                               % Current NL
Empty1.Average = [];                          % Previous NL
Empty1.Cost = inf;
Empty1.Members = [];
Experts = repmat (Empty, nNL, 1);             % Experts
n_it_phase1 = round(nIt*mIt_Phase1);          % Number of iterations in phase 1
n_it_phase2 = round(nIt*mIt_Phase2);          % Number of iterations in phase 2
n_it_phase3 = nIt-n_it_phase1-n_it_phase2;    % Number of iterations in phase 3
costs1 = zeros(n_it_phase1,1);                        % Costs of the phase 1
costs2 = zeros(n_it_phase2,1);                        % Costs of the phase 2
costs3 = zeros(n_it_phase3,1);                        % Costs of the phase 3
n_Groups = zeros(nModel,1);
Em.NL = [];
Em1.NL = [];
Em1.Cost = inf;
Expert_IbI = repmat (Em1, 1, 1);            % The best solution of the current generation
Logic = repmat (Em1, 1, 1);                 % The best solution before the current generation
Expert_new = repmat (Em1, 1, 1);
K0 = repmat (Em, nNL, 1);                   % Knowledge 0
K1 = repmat (Em, nNL, 1);                   % Knowledge 1
Expert_new.NL = [];
Expert_new.Cost = inf;
Knowledge_Phase1 = K0;
Knowledge_Phase2 = K0;
Knowledge_Phase3 = K0;
GroupNumber = ones(nNL,1);
Em2.NL = [];
Em2.Cost = inf;
Bests_Results = repmat (Em2, nIt, 1);

if length(Vmin) ~= (nV)
    Vmin=Vmin.*ones(1,nV);
    Vmax=Vmax.*ones(1,nV);
end

for i = 1:nNL
    Experts(i).NL = unifrnd(Vmin,Vmax,1,nV);
    Experts(i).NLprevious = unifrnd(Vmin,Vmax,1,nV);
    Experts(i).Cost = CostFunction(Experts(i).NL);
end

% Extract the Logic (Best NL in the previous solutions)
for i = 1:nNL
    if CostFunction(Experts(i).NLprevious) <= Logic.Cost
        Logic.Cost = CostFunction(Experts(i).NLprevious); % The best solution of before the current generation
        Logic.NL = Experts(i).NLprevious;
    end
    if Experts(i).Cost <= Expert_IbI.Cost
        Expert_IbI.Cost = Experts(i).Cost;    % The best solution of the current generation
        Expert_IbI.NL = Experts(i).NL;
    end
end

n_t = zeros(nModel,1);
nt = round((n_it_phase1)/nModel);
for m = 1:nModel
    n_t(m,1) = nt;
end
n_t(nModel,1) = (n_it_phase1)-(nModel-1)*nt;

for m = 1:nModel
    n_Groups(m,1) = randi(round(nNL/2));     % Number of workgropus in each model
end

%% Phase 0: Grouping (Clustering)

for m = 1:nModel
    
    % Clustering
    MAT = zeros(nNL,nV);
    for i = 1:nNL
        MAT(i,:) = Experts(i).NL;
    end
    opts = statset('MaxIter',nIt_classification);
    lastwarn('Success');
    GroupNumber0 = GroupNumber;
    GroupNumber = kmeans(MAT,n_Groups(m,1),'Distance','sqeuclidean','Replicates',nRep,'Options',opts);
    [warningMessage, warningMessageID] = lastwarn;
    if contains(warningMessage, 'Failed to converge')
        warnStruct = warning('off');
        GroupNumber = GroupNumber0;
        if m ==1
            n_Groups(m,1) = 1;
        else
            n_Groups(m,1) = n_Groups(m-1,1);
        end
    end
    Experts_Groups = repmat (Empty1, n_Groups(m,1),1);
    n_members = zeros(n_Groups(m,1),1);
    
    for c = 1:n_Groups(m,1)
        nn=0;
        for i = 1:nNL
            if GroupNumber(i,1) == c
                nn = nn+1;
            end
        end
        n_members(c,1) = nn;
        Experts_Groups(c).Members = repmat (Em, n_members(c,1), 1);
    end
    
    %% Phase 1: Workgropus
    for it_phase1 = 1:n_t(m,1)
        
        for c = 1:n_Groups(m,1)
            SUM = 0;
            num = 0;
            for i = 1:nNL
                if GroupNumber(i,1) == c
                    num = num+1;
                    SUM = Experts(i).NL + SUM;
                    Experts_Groups(c).Members(num).NL = Experts(i).NL;
                    if Experts(i).Cost <= Experts_Groups(c).Cost
                        Experts_Groups(c).NL = Experts(i).NL;
                        Experts_Groups(c).Cost = Experts(i).Cost;
                    end
                end
            end
            Experts_Groups(c).Average = SUM./n_members(c,1);
        end
        
        % Calculate the ratios
        D = zeros(nNL,1);
        P = zeros(nNL,1);
        C = zeros(nNL,1);
        for i = 1:nNL
            C(i,1) = sqrt(sum((Experts(i).NL-Logic.NL).^2));
            D(i,1) = sqrt(sum((Experts(i).NL-Experts(i).NLprevious).^2));
            P(i,1) = sqrt(sum((Experts(i).NL-Experts_Groups(GroupNumber(i,1)).NL).^2));
        end
        min_D = min(D); max_D = max(D);
        min_P = min(P); max_P = max(P);
        min_C = min(C); max_C = max(C);
        
        Rc = (C-min_C)./(max_C-min_C);
        Rp = (P-min_P)./(max_P-min_P);
        RD = (D-min_D)./(max_D-min_D);
        Bc = Bmin + (Bmax-Bmin)*rand();
        Bp = Bmin + (Bmax-Bmin)*rand();
        BD = Bmin + (Bmax-Bmin)*rand();
        
        for i = 1:nNL
            B = Bmin + (Bmax-Bmin)*rand();
            if (Rc(i,1) <= Bc) && (Rp(i,1) <= Bp)
                random_member = randi (n_members(GroupNumber(i,1),1));
                K0(i).NL = Rp(i,1).*(Experts(i).NL + Experts_Groups(GroupNumber(i,1)).Members(random_member).NL)./2;
            elseif (Rc(i,1) <= Bc) && (Rp(i,1) > Bp)
                K0(i).NL = Rp(i,1).*(Experts(i).NL + Experts_Groups(GroupNumber(i,1)).Average)./2;
            elseif (Rc(i,1) > Bc) && (Rp(i,1) <= Bp)
                random_member = randi (n_members(GroupNumber(i,1),1));
                K0(i).NL = Rp(i,1).*(Experts_Groups(GroupNumber(i,1)).NL + Experts_Groups(GroupNumber(i,1)).Members(random_member).NL)./2;
            elseif (Rc(i,1) > Bc) && (Rp(i,1) > Bp)
                K0(i).NL = Rp(i,1).*(Experts_Groups(GroupNumber(i,1)).NL + Experts_Groups(GroupNumber(i,1)).Average)./2;
            end
            
            if RD(i,1)<= BD
                K1(i).NL = (rand()).*(Experts_Groups(GroupNumber(i,1)).Average);
            else
                K1(i).NL = (rand()).*(unifrnd(Vmin,Vmax,1,nV));
            end
            
            Knowledge_Phase1(i).NL = abs(K0(i).NL + K1(i).NL)./2;
            
            % Update the NL
            alpha1 = -1.5+3.*rand(1,nV);
            Expert_new.NL = Experts(i).NL + alpha1.*(Knowledge_Phase1(i).NL);
            Expert_new.NL = max(Expert_new.NL, Vmin);
            Expert_new.NL = min(Expert_new.NL, Vmax);
            E1 = Experts(i).NL;
            Expert_new.Cost = CostFunction(Expert_new.NL);
            
            COEF = -1.5+3*rand();
            K = rand().*Experts_Groups(GroupNumber(i,1)).NL;
            NEW.NL = COEF.*(Expert_new.NL) + K;
            NEW.NL = max(NEW.NL, Vmin);
            NEW.NL = min(NEW.NL, Vmax);
            NEW.Cost = CostFunction(NEW.NL);
            if NEW.Cost < Expert_new.Cost
                Expert_new = NEW;
            end
            
            
            if Expert_new.Cost < Experts(i).Cost
                Experts(i).NL = Expert_new.NL;
                Experts(i).Cost = Expert_new.Cost;
            end
            if Experts(i).NL ~= E1
                Experts(i).NLprevious = E1;
            end
            E1 = Expert_IbI.NL;
            if Experts(i).Cost < Expert_IbI.Cost
                Expert_IbI.Cost = Experts(i).Cost;
                Expert_IbI.NL = Experts(i).NL;
            end
            if Expert_IbI.NL ~= E1
                Logic.NL = E1;
            end
        end
        
        costs1((m-1)*(n_t(1,1))+it_phase1,1) = Expert_IbI.Cost;
        Bests_Results((m-1)*(n_t(1,1))+it_phase1).NL = Expert_IbI.NL;
        Bests_Results((m-1)*(n_t(1,1))+it_phase1).Cost = Expert_IbI.Cost;
        
    end
end
NUM = n_it_phase1;
for it_phase2 = 1:n_it_phase2
NUM = NUM+1;    
    % Calculate the ratios
    for i = 1:nNL
        C(i,1) = sqrt(sum((Experts(i).NL-Logic.NL).^2));
        D(i,1) = sqrt(sum((Experts(i).NL-Experts(i).NLprevious).^2));
        P(i,1) = sqrt(sum((Experts(i).NL-Expert_IbI.NL).^2));
    end
    min_D = min(D); max_D = max(D);
    min_P = min(P); max_P = max(P);
    min_C = min(C); max_C = max(C);
    
    Rc = (C-min_C)./(max_C-min_C);
    Rp = (P-min_P)./(max_P-min_P);
    RD = (D-min_D)./(max_D-min_D);
    Bc = Bmin + (Bmax-Bmin)*rand();
    Bp = Bmin + (Bmax-Bmin)*rand();
    BD = Bmin + (Bmax-Bmin)*rand();
    
    for i = 1:nNL
        B = Bmin + (Bmax-Bmin)*rand();
        if (Rc(i,1) <= Bc) && (Rp(i,1) <= Bp)
            random_member = randi (nNL);
            K0(i).NL = Rp(i,1).*(Experts(i).NL + Experts(random_member).NL)./2;
        elseif (Rc(i,1) <= Bc) && (Rp(i,1) > Bp)
            SUM = 0;
            for ii = 1:nNL
                SUM = Experts(ii).NL + SUM;
            end
            Average = SUM./nNL;
            K0(i).NL = Rp(i,1).*(Experts(i).NL + Average)./2;
        elseif (Rc(i,1) > Bc) && (Rp(i,1) <= Bp)
            random_member = randi (nNL);
            K0(i).NL = Rp(i,1).*(Expert_IbI.NL + Experts(random_member).NL)./2;
        elseif (Rc(i,1) > Bc) && (Rp(i,1) > Bp)
            SUM = 0;
            for ii = 1:nNL
                SUM = Experts(ii).NL + SUM;
            end
            Average = SUM./nNL;
            K0(i).NL = Rp(i,1).*(Expert_IbI.NL + Average)./2;
        end
        
        if RD(i,1)<= BD
            SUM = 0;
            for ii = 1:nNL
                SUM = Experts(ii).NL + SUM;
            end
            Average = SUM./nNL;
            K1(i).NL = (rand()).*(Average);
        else
            K1(i).NL = (rand()).*(unifrnd(Vmin,Vmax,1,nV));
        end
        
        % Update the NL
        Knowledge_Phase2(i).NL = abs(K0(i).NL + K1(i).NL)./2;
        alpha2 = -0.75+1.5.*rand(1,nV);
        Expert_new.NL = Experts(i).NL + alpha2.*(Knowledge_Phase2(i).NL);
        Expert_new.NL = max(Expert_new.NL, Vmin);
        Expert_new.NL = min(Expert_new.NL, Vmax);
        E1 = Experts(i).NL;
        Expert_new.Cost = CostFunction(Expert_new.NL);
        
        COEF = -0.75+1.5*rand();
        K = rand().*(Expert_IbI.NL);
        NEW.NL = COEF.*(Expert_new.NL) + K;
        NEW.NL = max(NEW.NL, Vmin);
        NEW.NL = min(NEW.NL, Vmax);
        NEW.Cost = CostFunction(NEW.NL);
        
        if NEW.Cost < Expert_new.Cost
            Expert_new = NEW;
        end
        
        if Expert_new.Cost < Experts(i).Cost
            Experts(i).NL = Expert_new.NL;
            Experts(i).Cost = Expert_new.Cost;
        end
        if Experts(i).NL ~= E1
            Experts(i).NLprevious = E1;
        end
        E1 = Expert_IbI.NL;
        if Experts(i).Cost < Expert_IbI.Cost
            Expert_IbI.Cost = Experts(i).Cost;
            Expert_IbI.NL = Experts(i).NL;
        end
        if Expert_IbI.NL ~= E1
            Logic.NL = E1;
        end
    end
    
    costs2(it_phase2,1) = Expert_IbI.Cost;
    Bests_Results(NUM).NL = Expert_IbI.NL;
    Bests_Results(NUM).Cost = Expert_IbI.Cost;
end

%% Phase 3: IbI Logic Search

for it_phase3 = 1:n_it_phase3
NUM = NUM+1;    
    for i = 1:nNL
        SUM = 0;
        for ii = 1:nNL
            SUM = SUM + Experts(ii).NL;
        end
        Average = SUM./nNL;
        
        factor = randi(2);
        if factor == 1
            Knowledge_Phase3(i).NL = abs(Average - Experts(randi(nNL)).NL);
        else
            Knowledge_Phase3(i).NL = abs(Average - Expert_IbI.NL);
        end
        alpha3 = -0.25+0.5.*rand(1,nV);
        Expert_new.NL = Experts(i).NL + alpha3.*(Knowledge_Phase3(i).NL);
        
        Expert_new.NL = max(Expert_new.NL, Vmin);
        Expert_new.NL = min(Expert_new.NL, Vmax);
        Expert_new.Cost = CostFunction(Expert_new.NL);
        
        COEF = -0.25+0.5*rand();
        K = rand().*(Expert_IbI.NL);
        NEW.NL = COEF.*(Expert_new.NL) + K;
        NEW.NL = max(NEW.NL, Vmin);
        NEW.NL = min(NEW.NL, Vmax);
        NEW.Cost = CostFunction(NEW.NL);
        if NEW.Cost < Expert_new.Cost
            Expert_new = NEW;
        end
        
        if Expert_new.Cost < Experts(i).Cost
            Experts(i).NL = Expert_new.NL;
            Experts(i).Cost = Expert_new.Cost;
        end
        if Experts(i).Cost < Expert_IbI.Cost
            Expert_IbI.Cost = Experts(i).Cost;
            Expert_IbI.NL = Experts(i).NL;
        end
    end
    costs3(it_phase3,1) = Expert_IbI.Cost;
    Bests_Results(NUM).NL = Expert_IbI.NL;
    Bests_Results(NUM).Cost = Expert_IbI.Cost;
end

%% Extract the results
Expert_IbI.Cost = CostFunction(Expert_IbI.NL);

end