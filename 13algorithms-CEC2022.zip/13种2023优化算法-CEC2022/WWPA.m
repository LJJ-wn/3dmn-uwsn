% Waterwheel Plant Algorithm,WWPA
% https://doi.org/10.3390/pr11051502

function [besty,bestx,cg]=WWPA(nPop,Maxiter,lb,ub,dim,fobj)
lb=lb.*ones(1,dim);
ub=ub.*ones(1,dim);
% Population initialization
x=initialization(nPop,dim,ub,lb);

iter=1;
cg=zeros(1,Maxiter);
for i=1:size(x,1)
    % fitness of locations
    fitness(i)=fobj(x(i,:));
    if fitness(i)<inf
        besty= fitness(i);
        bestx=x(i,:);
    end
end
cg(1)=besty;
% main loop
while iter<Maxiter
    iter=iter+1;
% Explore
    if rand<0.5
        K=exprnd (1, 1);
        W=rand(1,dim).*(x+2*K);
        x=x+W.*(2*K+rand(1,dim));
        for i=1:size(x,1)
            % fitness of locations
            fitness(i)=fobj(x(i,:));
            if fitness(i)<besty
                besty= fitness(i);
                bestx=x(i,:);
            end
        end
        cg(iter)=besty;
        if iter>=3
            if cg(iter-2)==cg(iter-1) && cg(iter-1)==cg(iter)
                for i=1:size(x,1)                    
                    x(i,:)=normrnd(mean(x(i,:)), std(x(i,:)),1,dim)+rand(1,dim).*(x(i,:)+2*K)./W(i,:);
                end
            end
            % Check boundries
            FU=x>ub;FL=x<lb;
            x=(x.*(~(FU+FL)))+ub.*FU+lb.*FL;
            for i=1:size(x,1)
                % fitness of locations
                fitness(i)=fobj(x(i,:));
                if fitness(i)<besty
                    besty= fitness(i);
                    bestx=x(i,:);
                end
            end
        end
        cg(iter)=besty;
   % Exploit     
    else
        F=5*rand;C=5*rand;
        K = (1 + 2*iter^2/ Maxiter+ F);
        theta=pi;
        r3=2-2*rand(1,dim);
        W=r3.*(K.*bestx+r3.*x);
        x=x+K.*W;
        for i=1:size(x,1)
            % fitness of locations
            fitness(i)=fobj(x(i,:));
            if fitness(i)<besty
                besty= fitness(i);
                bestx=x(i,:);
            end
        end
        cg(iter)=besty;
        if iter>=3
            if cg(iter-2)==cg(iter-1) && cg(iter-1)==cg(iter)
                
                x=(rand(1,dim)+K).*sin(F*theta/C);
            end
            % Check boundries
            FU=x>ub;FL=x<lb;
            x=(x.*(~(FU+FL)))+ub.*FU+lb.*FL;
            for i=1:size(x,1)
                % fitness of locations
                fitness(i)=fobj(x(i,:));
                if fitness(i)<besty
                    besty= fitness(i);
                    bestx=x(i,:);
                end
            end
        end
        cg(iter)=besty;
    end
    
end

end

% This function initialize the first population of search agents
function Positions=initialization(SearchAgents_no,dim,ub,lb)

Boundary_no= size(ub,2); % number of boundaries

% If the boundaries of all variables are equal and user enter a signle
% number for both ub and lb
if Boundary_no==1
    Positions=rand(SearchAgents_no,dim).*(ub-lb)+lb;
end

% If each variable has a different lb and ub
if Boundary_no>1
    for i=1:dim
        ub_i=ub(i);
        lb_i=lb(i);
        Positions(:,i)=rand(SearchAgents_no,1).*(ub_i-lb_i)+lb_i;
    end
end
end
